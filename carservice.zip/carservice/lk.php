<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit();
}

// Подключение к базе данных
include 'application/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>АвтоПрофи</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  <style type="text/css">
    .empty{
      height: 400px;
    }

    @media(max-width: 640px){
      .empty{
        height: 100px;
      }
    }
    .navbar {
            display: flex;
            justify-content: center;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand img {
            height: 50px;
        }
        .nav-link {
            color: #343a40;
            font-weight: 500;
            padding: 0 12px;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #007bff;
        }
  </style>
  <nav class="navbar navbar-expand-lg navbar-light bg-white">
    <a class="navbar-brand" href="index.php"><img src="img/logo.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php" style="color: red !important;">Главная <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="catalog.php" style="color: red !important;">Услуги</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php" style="color: red !important;">Контакты</a>
        </li>
        <li class="nav-item">
          <?php
          if (isset($_SESSION['id'])) {
            echo '<a href="lk.php" class="nav-link" style="color: red !important;">Личный кабинет</a>';
          } else {
              echo '<a href="login.php" class="nav-link" style="color: red !important;">Личный кабинет</a>';
            }
          ?>
        </li>
      </ul>
    </div>
</nav>

  <section class="container mt-5">
    <h2 class="mb-4">Личный кабинет</h2>
    <div class="row">
      <div class="col-md-6">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title" style="font-size: 32px;">Информация о пользователе</h5>
            <p class="card-text">
              <form action="logout.php" method="post" style="font-size: 28px;">
                <p>ФИО: <span class="info" id="user-name"><?php echo
                    isset($_SESSION['login']) ? $_SESSION['login'] : ''; ?></span></p>
                <p>Возраст: <span class="info" id="user-age"><?php echo
                    isset($_SESSION['age']) ? $_SESSION['age'] : ''; ?></span></p>
                <p>Email: <span class="info" id="user-email"><?php echo
                    isset($_SESSION['email']) ? $_SESSION['email'] : ''; ?></span></p>
                <button type="submit" name="logoutButton" class="btn btn-danger">Выйти</button>
              </form>
            </p>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title" style="font-size: 32px;">Заявка на починку машины</h5>
            <form action="#" method="post" style="font-size: 28px;">
              <div class="form-group">
                <label for="car-model">Модель автомобиля</label>
                <input type="text" class="form-control" id="car-model" name="car_model" required>
              </div>
              <div class="form-group">
                <label for="car-problem">Описание проблемы</label>
                <textarea class="form-control" id="car-problem" name="car_problem" rows="3" required></textarea>
              </div>
              <button type="submit" class="btn btn-danger">Отправить заявку</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <div class="empty"> </div>
  <footer class="bg-white text-white text-center py-4 mt-5" style="color: red !important;">
    &copy; 2024 АвтоПрофи. Все права защищены.
  </footer>


  <script src="lk.js" defer></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
