-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 27 2024 г., 18:33
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `kurs`
--

-- --------------------------------------------------------

--
-- Структура таблицы `courses`
--

CREATE TABLE `courses` (
  `id` int NOT NULL,
  `name` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `courses`
--

INSERT INTO `courses` (`id`, `name`, `image`, `url`, `description`, `price`) VALUES
(1, 'Курс Python', 'img/python.jpg', 'course.php?id=1', 'Курс содержит все основы языка программирования Python и практические задания', '5000.00'),
(2, 'Курс C#', 'img/csharp.png', 'course.php?id=2', 'Курс содержит все основы языка программирования C# и практические задания', '5000.00'),
(3, 'Курс C++', 'img/cplus.png', 'course.php?id=3', 'Курс содержит все основы языка программирования C++ и практические задания', '5000.00'),
(4, 'Курс Java', 'img/java.png', 'course.php?id=4', 'Курс содержит все основы языка программирования Java и практические задания', '5000.00'),
(5, 'Курс PHP', 'img/php.jpg', 'course.php?id=5', 'Курс содержит все основы языка программирования PHP и практические задания', '5000.00'),
(6, 'Курс JavaScript', 'img/js.png', 'course.php?id=6', 'Курс содержит все основы языка программирования JavaScript и практические задания', '5000.00');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `course_id` int NOT NULL,
  `order_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `course_id`, `order_date`) VALUES
(2, 14, 1, '2024-06-18 14:20:11'),
(3, 15, 3, '2024-06-18 14:28:56'),
(6, 16, 2, '2024-06-27 12:40:47'),
(7, 14, 5, '2024-06-27 13:18:03'),
(8, 15, 3, '2024-06-27 13:18:26');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `admin` tinyint NOT NULL,
  `us_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `age` tinyint DEFAULT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `admin`, `us_name`, `email`, `age`, `password`) VALUES
(14, 0, 'Влад', 'fghjk@mail.ru', 18, '$2y$10$n/WKFpzlNTDXNc.B6hC9u.OfA.LgMse53pbTUXvlF/iPuTfP24QLm'),
(15, 0, 'Стас', 'ghjk@ghj', 22, '$2y$10$71HtoDXsw/pDTqRFVzX8F.LBWVagfQ/vjABoVr/rdAvxSBDcsyry6'),
(16, 0, 'Никита', 'fghjkddd@mail.ru', 25, '$2y$10$hPwgKxOHFdoExgNksHneVuP/XI1pQbOj/5SZ8hxlmfvLb10vOcbrS');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
