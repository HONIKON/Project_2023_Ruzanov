<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>АвтоПрофи</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  <style type="text/css">
    p{
      font-size: 24px;
    }
    .list{
      font-size: 24px;
    }
    
    @media(min-width: 700px){
      .empty{
      margin-bottom: 200px;
    }
    }
    .navbar {
            display: flex;
            justify-content: center;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand img {
            height: 50px;
        }
        .nav-link {
            color: #343a40;
            font-weight: 500;
            padding: 0 12px;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #007bff;
        }
        .map-container {
      position: relative;
      width: 100%;
      height: 0;
      padding-bottom: 56.25%;
    }
    .map-container iframe {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    }
  </style>
  <nav class="navbar navbar-expand-lg navbar-light bg-white">
    <a class="navbar-brand" href="index.php"><img src="img/logo.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php" style="color: red !important;">Главная <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="catalog.php" style="color: red !important;">Услуги</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php" style="color: red !important;">Контакты</a>
        </li>
        <li class="nav-item">
          <?php
          if (isset($_SESSION['id'])) {
            echo '<a href="lk.php" class="nav-link" style="color: red !important;">Личный кабинет</a>';
          } else {
              echo '<a href="login.php" class="nav-link" style="color: red !important;">Личный кабинет</a>';
            }
          ?>
        </li>
      </ul>
    </div>
</nav>


  <section class="container mt-5">
    <h2 class="mb-4 text-center" style="color: red !important;">О нашем сервисе</h2>
    <p>Добро пожаловать в наш профессиональный центр по ремонту автомобилей! Наша команда состоит из опытных механиков и технических специалистов, которые постоянно повышают свою квалификацию, чтобы предоставить вам наилучший сервис. Мы предлагаем широкий спектр услуг, включая плановое техническое обслуживание, диагностику и ремонт автомобилей всех марок и моделей.

Наше современное оборудование оснащено новейшими инструментами и технологиями для обеспечения точного и эффективного обслуживания. Мы используем только высококачественные запчасти и следуем рекомендациям производителя, чтобы обеспечить бесперебойную и безопасную работу вашего автомобиля на дороге. Наша цель - предоставить вам надежные и доступные услуги по ремонту автомобилей, которые превзойдут ваши ожидания!</p>
    
  </section>

  <section class="container mt-5">
    <h2 class="mb-4" style="color: red !important;">Контактная информация</h2>
    <ul class="list">
        <li>Email: avtoprofi@mail.ru</li>
        <li>Телефон: +7 (385) 589-25-25</li>
    </ul>
  </section>
  <div class="map-container">
    <iframe
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d76231.83477050763!2d83.57949984335941!3d53.3388733!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x42dda38c25d6dc73%3A0x1d006c36d8008171!2z0JDQstGC0L7Qn9GA0L7RhNC4IDIy!5e0!3m2!1sru!2sru!4v1719651984568!5m2!1sru!2sru"
      width="400"
      height="400"
      style="border:0;"
      allowfullscreen=""
      loading="lazy"
      referrerpolicy="no-referrer-when-downgrade"
    ></iframe>
  </div>




  <footer class="bg-white text-white text-center py-4 mt-5" style="color: red !important;">
    &copy; 2024 АвтоПрофи. Все права защищены.
  </footer>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
