document.addEventListener("DOMContentLoaded", async function () {
    const userEmail = document.getElementById("user-email");
    async function loadProfileInfo() {
    try {
    const response = await fetch('getProfileInfo.php', {
    method: 'POST',
    });
    const data = await response.text();
    const [email, created, info] = data.split('|');
    userEmail.innerText = email;
} catch (error) {
console.error(error.message);
}
}
loadProfileInfo();
});