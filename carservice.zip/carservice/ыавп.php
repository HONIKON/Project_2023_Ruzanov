<a href="order.php?course_id=<?php echo $course['id']; ?>" class="btn btn-danger">Отправить заявку</a>
<?php
          if (isset($_SESSION['id'])) {
            echo '<a href="lk.php" class="btn btn-danger">Отправить заявку</a>';
          } else {
              echo '<a href="login.php" class="btn btn-danger">Отправить заявку</a>';
            }
          ?>