<?php
session_start();
include 'application/db.php';

// Получение ID курса из URL
$courseId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($courseId > 0) {
    $query = "SELECT * FROM service WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $courseId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $course = $result->fetch_assoc();
    } else {
        echo "Услуга не найден.";
        exit();
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Неверный идентификатор услуги.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo htmlspecialchars($course['name']); ?> - Автосервис</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
        .navbar {
            display: flex;
            justify-content: center;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand img {
            height: 50px;
        }
        .nav-link {
            color: #343a40;
            font-weight: 500;
            padding: 0 12px;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #007bff;
        }
        
       
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white">
    <a class="navbar-brand" href="index.php"><img src="img/logo.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php" style="color: red !important;">Главная <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="catalog.php" style="color: red !important;">Услуги</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php" style="color: red !important;">Контакты</a>
        </li>
        <li class="nav-item">
          <?php
          if (isset($_SESSION['id'])) {
            echo '<a href="lk.php" class="nav-link" style="color: red !important;">Личный кабинет</a>';
          } else {
              echo '<a href="login.php" class="nav-link" style="color: red !important;">Личный кабинет</a>';
            }
          ?>
        </li>
      </ul>
    </div>
</nav>


  <section class="container mt-5">
    <div class="row">
      <div class="col-md-8 mx-auto">
        <div class="card mb-4">
          <img src="<?php echo htmlspecialchars($course['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($course['name']); ?>">
          <div class="card-body">
            <h5 class="card-title"><?php echo htmlspecialchars($course['name']); ?></h5>
            <p class="card-text"><?php echo nl2br(htmlspecialchars($course['description'])); ?></p>
            <p class="card-text"><strong>Цена:</strong> <?php echo number_format($course['price'], 2, ',', ' '); ?> руб.</p>
            <a href="catalog.php" class="btn btn-danger">Назад к услугам</a>
            <?php
          if (isset($_SESSION['id'])) {
            echo '<a href="lk.php" class="btn btn-danger">Отправить заявку</a>';
          } else {
              echo '<a href="login.php" class="btn btn-danger">Отправить заявку</a>';
            }
          ?>
          </div>
        </div>
      </div>
    </div>
  </section>

  <footer class="bg-white text-white text-center py-4 mt-5" style="color: red !important;">
    &copy; 2024 АвтоПрофи. Все права защищены.
  </footer>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
